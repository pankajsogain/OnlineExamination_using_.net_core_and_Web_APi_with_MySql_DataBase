﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OEA.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OEA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdminController : ControllerBase
    {
        private readonly OeaContext _context;
        public AdminController(OeaContext context)
        {
            _context = context;
        }
        // POST api/<AdminController>
        [HttpPost("Registration")]
        public IActionResult Registration(Registration registration)
        {
            var role=_context.Rolemaster.Where(x => x.RoleName ==registration.Role).FirstOrDefault();

            Customeraccount customeraccount = new Customeraccount
            {
                FirstName = registration.FirstName,
                LastName = registration.LastName,
                EmailId = registration.EmailId,
                Password = EncriptionDescription.Encrypt(registration.Password),
                PhoneNumber = registration.PhoneNumber,
                Country = registration.Country,
                State = registration.State,
                City = registration.City,
                TandC = Convert.ToByte(registration.TAndC)
            };
            _context.Customeraccount.Add(customeraccount);
            _context.SaveChanges();
            _context.Customerrole.Add(new Customerrole { RoleId = role.RoleId, CustId = customeraccount.CustId,RoleName=role.RoleName });
            _context.SaveChanges();
            return Ok();
        }
        
        [HttpPost("CreateTestAsync")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult CreateTestAsync(Simtest simtest)
        {
            _context.Simtest.Add(simtest);
            _context.SaveChanges();            
            return Ok();
        }

        [HttpGet("GetAllSimTest")]
        [ProducesResponseType(typeof(IEnumerable<Simtest>), StatusCodes.Status200OK)]
        public IActionResult GetAllSimTest()
        {
           var simtest=_context.Simtest.ToList();
           return Ok(simtest);
        }
        
            [HttpGet("DeleteSimTest")]
        public IActionResult DeleteSimTest(int simtestid)
        {
            if (_context.Simtest.Where(x => x.SimTestNumber == simtestid).Any())
            {
                var sim=_context.Simtest.Where(x => x.SimTestNumber == simtestid).FirstOrDefault();
                _context.Simtest.Remove(sim);
                _context.SaveChanges();
                return Ok();
            }
            else
                return NotFound();
        }
        
         [HttpGet("GetSimTest")]
        public IActionResult GetSimTest(int simtestid)
        {
            if (_context.Simtest.Where(x => x.SimTestNumber == simtestid).Any())
                return Ok(_context.Simtest.Where(x => x.SimTestNumber == simtestid).FirstOrDefault());
            else
                return NotFound();
        }
        [HttpPost("UpdateSimTest")]
        public IActionResult UpdateSimTest(Simtest simtest)
        {
            if (_context.Simtest.Where(x => x.SimTestNumber == simtest.SimTestNumber).Any())
            {
                _context.Simtest.Update(simtest);
                _context.SaveChanges();
                return Ok();
            }
            else
            {
                return NotFound();
            }              
        }
        
        [HttpGet("GetQuetionsBySimTestId")]
        public IActionResult GetQuetionsBySimTestId(int simtestId)
        {
            VmQuestions vmQuestions = new VmQuestions();
            if(_context.Simtest.Where(x => x.SimTestNumber== simtestId).Any())
            {
                vmQuestions.SimTest= _context.Simtest.Where(x => x.SimTestNumber == simtestId).FirstOrDefault();
                 var questions=_context.Questions.Where(x => x.TestId == simtestId).ToList();
                vmQuestions.SimTest.NoofQuestions = questions.Count();
                vmQuestions.Questionwithchoices = new List<Questionwithchoice>();
                foreach (Questions item in questions)
                {
                    Questionwithchoice questionwithchoice = new Questionwithchoice();
                    questionwithchoice.questions = item;
                    questionwithchoice.choices = _context.Choices.FirstOrDefault(x => x.QuestionId == item.IdQuestions);
                    vmQuestions.Questionwithchoices.Add(questionwithchoice);
                }                                 
                return Ok(vmQuestions);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost("AddQuestion")]
        public IActionResult AddQuestion(Questionwithchoice questionwithchoice)
        {
            if (_context.Simtest.Where(x => x.SimTestNumber == questionwithchoice.questions.TestId).Any())
            {
                _context.Questions.Add(questionwithchoice.questions);
                _context.SaveChanges();
                var choices = questionwithchoice.choices;
                choices.QuestionId = questionwithchoice.questions.IdQuestions;
                _context.Choices.Add(choices);
                _context.SaveChanges();
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPost("AssignTest")]
        public IActionResult AssignTest(Assignedtest assignedtest)
        {
            if (_context.Simtest.Where(x => x.SimTestNumber == assignedtest.TestId).Any()
                && _context.Customeraccount.Where(x => x.CustId == assignedtest.CustId).Any())
            {
                if (_context.Assignedtest.Where(x => x.TestId == assignedtest.TestId).Any())
                {
                    var assignedtests=_context.Assignedtest.Where(x => x.TestId == assignedtest.TestId).Where(x=>x.CustId==assignedtest.CustId);
                    _context.Assignedtest.RemoveRange(assignedtests);
                    _context.SaveChanges();
                }               
                _context.Assignedtest.Add(assignedtest);
                _context.SaveChanges();               
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet("GetCustomers")]
        [ProducesResponseType(typeof(IEnumerable<VmCustomer>), StatusCodes.Status200OK)]
        public IActionResult GetCustomers()
        {
            var customers=_context.Customeraccount.ToList();
            List<VmCustomer> vmCustomers = new List<VmCustomer>();
            foreach (var item in customers)
            {
                vmCustomers.Add(new VmCustomer { CustId =item.CustId,FirstName=item.FirstName,LastName=item.LastName,EmailId=item.EmailId });
            }
            return Ok(vmCustomers);
            
        }
        [HttpPost("CheckResult")]
        [ProducesResponseType(typeof(Assignedtest), StatusCodes.Status200OK)]
        public IActionResult CheckResult(VmQuestions vmQuestions)
        {
            int InCorrectCount = 0;
            int CorrectCount = 0;
            foreach (var item in vmQuestions.Questionwithchoices)
            {
                if(_context.Choices.Where(x => x.QuestionId == item.questions.IdQuestions && x.Answer == item.questions.CorrectAnswer).Any())
                {
                    CorrectCount++;
                }
                else
                {
                    InCorrectCount++;
                }
            }

            var assignment=_context.Assignedtest.FirstOrDefault(x => x.TestId == vmQuestions.Questionwithchoices[0].questions.TestId && x.CustId == vmQuestions.CustId);
            assignment.NoOfCorrectAnswers = CorrectCount;
            assignment.NoOfWrongAnswers = InCorrectCount;
            assignment.Percentage = ((CorrectCount/vmQuestions.Questionwithchoices.Count())*100);
            _context.Assignedtest.Update(assignment);
            _context.SaveChanges();
            return Ok(assignment);

        }


    }
}
