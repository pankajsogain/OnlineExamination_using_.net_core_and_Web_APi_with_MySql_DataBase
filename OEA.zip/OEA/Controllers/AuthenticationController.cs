﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using OEA.Models;

namespace OEA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly OeaContext _context;
        public IConfiguration Configuration { get; }
        public AuthenticationController(OeaContext context,IConfiguration configuration)
        {
            _context = context;
            Configuration = configuration;
        }
        
        [HttpPost("LoginUser")]
        public string LoginUser(User user)
        {
            var userdata = _context.Customeraccount.Where(x => x.EmailId == user.Email).Where(x=>x.Password== EncriptionDescription.Encrypt(user.Password)).FirstOrDefault();
            
            
            if (userdata!=null)
            {
                var role = _context.Customerrole.Where(x => x.CustId == userdata.CustId).FirstOrDefault();
                var key = Encoding.ASCII.GetBytes("YourKey-2374-OFFKDI940NG7:56753253-tyuw-5769-0921-kfirox29zoxv");
                var JWToken = new JwtSecurityToken(
                    issuer: "https://localhost:44370/",
                    audience: "https://localhost:44370/",
                    claims: GetUserClaims(userdata,role.RoleName),
                    notBefore: new DateTimeOffset(DateTime.Now).DateTime,
                    expires: new DateTimeOffset(DateTime.Now.AddDays(1)).DateTime,
                    signingCredentials: new SigningCredentials
                    (new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                );
                var token = new JwtSecurityTokenHandler().WriteToken(JWToken);                
                return role.RoleName+ ":"+ token+":"+ userdata.CustId;
            }
            else
            {
                return null;
            }
        }
        private IEnumerable<Claim> GetUserClaims(Customeraccount user,string role)
        {            
            IEnumerable<Claim> claims = new Claim[]
            {
              new Claim(ClaimTypes.Name, user.FirstName + " " + user.LastName),
              new Claim("EmailId", user.EmailId),
              new Claim("Role",role)        
            };
            return claims;
        }
    }
}
