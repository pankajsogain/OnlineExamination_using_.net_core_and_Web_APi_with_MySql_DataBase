﻿using Microsoft.AspNetCore.Authorization.Infrastructure;
using System.Collections.Generic;
namespace OEA.Models
{
    public class AdminManagerAuthorizationOverrideOthers : RolesAuthorizationRequirement
    {
        public AdminManagerAuthorizationOverrideOthers(IEnumerable<string> allowedRoles) : base(allowedRoles)
        {
        }
    }
}
