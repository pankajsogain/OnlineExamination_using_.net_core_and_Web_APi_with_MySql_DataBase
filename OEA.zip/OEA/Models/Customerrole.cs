﻿using System;
using System.Collections.Generic;

namespace OEA.Models
{
    public partial class Customerrole
    {
        public int? RoleId { get; set; }
        public int? CustId { get; set; }
        public string RoleName { get; set; }
        public int Id { get; set; }
    }
}
