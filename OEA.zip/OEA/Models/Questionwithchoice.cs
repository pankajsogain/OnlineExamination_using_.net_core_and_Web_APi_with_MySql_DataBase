﻿
namespace OEA.Models
{
    public class Questionwithchoice
    {
        public Questions questions { get; set; }
        public Choices choices { get; set; }
    }
}
