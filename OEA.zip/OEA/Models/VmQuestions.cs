﻿using System.Collections.Generic;

namespace OEA.Models
{
    public class VmQuestions
    {
        public int CustId { get; set; }
        public Simtest SimTest { get; set; }
        public List<Questionwithchoice> Questionwithchoices { get; set; }
    }
}
